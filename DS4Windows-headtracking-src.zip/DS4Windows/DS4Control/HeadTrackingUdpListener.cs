using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace DS4Windows
{
    /// <summary>
    /// Receives 6DOF head-tracking data over UDP in the OpenTrack wire format
    /// produced by the VRCompanion 6DOFtoUDP sender:
    ///
    ///   48 bytes = 6 little-endian Float64 in order:
    ///     x, y, z            (centimetres)
    ///     yaw, pitch, roll   (degrees)
    ///
    /// The sender already recenters (deltas from a reference pose) and wraps yaw,
    /// so values arrive normalized around zero. That is the right quantity for
    /// DIRECT AXIS MAPPING (orientation -> stick), but NOT for the gyro path,
    /// which expects angular velocity. We therefore also derive angular velocity
    /// (deg/s) here so gyro-hijack mode has a drop-in replacement for the
    /// controller's real gyro.
    /// </summary>
    public class HeadTrackingUdpListener
    {
        public const int PacketSize = 48;

        private readonly object _lock = new object();

        // Latest absolute (recentered) pose.
        private double _x, _y, _z;          // cm
        private double _yaw, _pitch, _roll; // deg

        // Previous sample + derived angular velocity (deg/s).
        private double _prevYaw, _prevPitch, _prevRoll;
        private double _velYaw, _velPitch, _velRoll;

        private long _lastPacketTicks;
        private bool _hasSample;

        private UdpClient _udp;
        private CancellationTokenSource _cts;
        private Task _receiveTask;

        private readonly System.Diagnostics.Stopwatch _clock =
            System.Diagnostics.Stopwatch.StartNew();

        public bool IsRunning { get; private set; }
        public int Port { get; private set; }
        public string BoundAddress { get; private set; }

        /// <param name="bindAddress">Use "127.0.0.1" for a local sender, or "0.0.0.0" to accept from another machine.</param>
        /// <param name="port">Must match the PORT set in 6DOFtoUDP.py. NOTE: only one process can bind a UDP port,
        /// so if OpenTrack / another mod already listens on 4242, point the sender at a different port (e.g. 4243) for DS4Windows.</param>
        public void Start(string bindAddress = "127.0.0.1", int port = 4242)
        {
            if (IsRunning) return;

            // The sender writes via System.BitConverter on the same machine; that is
            // little-endian on x86/x64. If you ever run on a big-endian arch, reverse
            // each 8-byte slice before ToDouble.
            Port = port;
            BoundAddress = bindAddress;
            var ep = new IPEndPoint(IPAddress.Parse(bindAddress), port);
            _udp = new UdpClient(ep);
            _cts = new CancellationTokenSource();
            _receiveTask = Task.Run(() => ReceiveLoop(_cts.Token));
            IsRunning = true;
        }

        public void Stop()
        {
            if (!IsRunning) return;
            IsRunning = false;

            try { _cts?.Cancel(); } catch { }
            try { _udp?.Close(); } catch { }
            try { _receiveTask?.Wait(500); } catch { }

            _udp?.Dispose();
            _udp = null;
            _cts?.Dispose();
            _cts = null;

            lock (_lock) { _hasSample = false; }
        }

        private async Task ReceiveLoop(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    UdpReceiveResult result = await _udp.ReceiveAsync().ConfigureAwait(false);
                    if (result.Buffer.Length >= PacketSize)
                        Parse(result.Buffer);
                }
                catch (ObjectDisposedException) { break; }
                catch (SocketException) { if (token.IsCancellationRequested) break; }
                catch { /* ignore malformed datagram, keep listening */ }
            }
        }

        private void Parse(byte[] b)
        {
            double x     = BitConverter.ToDouble(b, 0);
            double y     = BitConverter.ToDouble(b, 8);
            double z     = BitConverter.ToDouble(b, 16);
            double yaw   = BitConverter.ToDouble(b, 24);
            double pitch = BitConverter.ToDouble(b, 32);
            double roll  = BitConverter.ToDouble(b, 40);

            long now = _clock.ElapsedTicks;

            lock (_lock)
            {
                if (_hasSample)
                {
                    double dt = (now - _lastPacketTicks) /
                                (double)System.Diagnostics.Stopwatch.Frequency;
                    if (dt > 1e-4) // ignore absurdly small dt
                    {
                        _velYaw   = WrapDeg(yaw - _prevYaw) / dt;
                        _velPitch = (pitch - _prevPitch) / dt;
                        _velRoll  = (roll - _prevRoll) / dt;
                    }
                }

                _prevYaw = yaw; _prevPitch = pitch; _prevRoll = roll;

                _x = x; _y = y; _z = z;
                _yaw = yaw; _pitch = pitch; _roll = roll;
                _lastPacketTicks = now;
                _hasSample = true;
            }
        }

        private static double WrapDeg(double d)
        {
            if (d > 180.0) return d - 360.0;
            if (d < -180.0) return d + 360.0;
            return d;
        }

        /// <summary>
        /// Latest pose. Returns false if no packet has arrived yet.
        /// Check <see cref="HeadPose.Stale"/> before trusting it in hijack mode.
        /// </summary>
        public bool TryGetPose(out HeadPose pose, double maxAgeMs = 200.0)
        {
            lock (_lock)
            {
                if (!_hasSample)
                {
                    pose = default;
                    return false;
                }

                double ageMs = (_clock.ElapsedTicks - _lastPacketTicks) * 1000.0 /
                               System.Diagnostics.Stopwatch.Frequency;

                pose = new HeadPose
                {
                    X = _x, Y = _y, Z = _z,
                    Yaw = _yaw, Pitch = _pitch, Roll = _roll,
                    AngVelYaw = _velYaw, AngVelPitch = _velPitch, AngVelRoll = _velRoll,
                    AgeMs = ageMs,
                    Stale = ageMs > maxAgeMs
                };
                return true;
            }
        }
    }

    public struct HeadPose
    {
        public double X, Y, Z;                            // cm, recentered
        public double Yaw, Pitch, Roll;                   // deg, recentered
        public double AngVelYaw, AngVelPitch, AngVelRoll; // deg/s, derived
        public double AgeMs;
        public bool Stale;
    }
}
