using System;
using System.IO;
using System.Text.Json;

namespace DS4Windows
{
    /// <summary>
    /// Saves/restores the per-controller OSIRIS head-tracking settings to a small
    /// JSON file in the app's config folder. Kept separate from DS4Windows' own
    /// Profiles.xml so it can't corrupt existing config. Load() runs at startup,
    /// Save() at shutdown.
    /// </summary>
    public static class HeadTrackingPersistence
    {
        private static string FilePath =>
            Path.Combine(string.IsNullOrEmpty(Global.appdatapath) ? "." : Global.appdatapath,
                         "headtracking.json");

        // Plain data object: only the fields we persist (no computed properties).
        private class Dto
        {
            public bool Enabled { get; set; }
            public string IpAddress { get; set; } = "127.0.0.1";
            public int Port { get; set; } = 4242;
            public HeadTrackingMode Mode { get; set; } = HeadTrackingMode.Off;
            public bool InvertYaw { get; set; }
            public bool InvertPitch { get; set; }
            public bool InvertRoll { get; set; }
            public bool InvertX { get; set; }
            public bool InvertY { get; set; }
            public bool InvertZ { get; set; }
            public double YawGain { get; set; } = 0.05;
            public double PitchGain { get; set; } = 0.05;
            public double RollGain { get; set; } = 0.05;
            public double XGain { get; set; } = 0.05;
            public double YGain { get; set; } = 0.05;
            public double ZGain { get; set; } = 0.05;
            public double StickRangeDeg { get; set; } = 40.0;
            public double GyroScale { get; set; } = 1.0;
            public double MaxAgeMs { get; set; } = 200.0;
            public bool MapPosition { get; set; }
            public double GlobalSensitivity { get; set; } = 1.0;
            public double GlobalSmoothing { get; set; } = 0.0;
        }

        public static void Save()
        {
            try
            {
                var arr = new Dto[Global.MAX_DS4_CONTROLLER_COUNT];
                for (int i = 0; i < arr.Length; i++)
                {
                    HeadTrackingSettings s = Global.headTracking[i];
                    arr[i] = new Dto
                    {
                        Enabled = s.Enabled,
                        IpAddress = s.IpAddress,
                        Port = s.Port,
                        Mode = s.Mode,
                        InvertYaw = s.InvertYaw,
                        InvertPitch = s.InvertPitch,
                        InvertRoll = s.InvertRoll,
                        InvertX = s.InvertX,
                        InvertY = s.InvertY,
                        InvertZ = s.InvertZ,
                        YawGain = s.YawGain,
                        PitchGain = s.PitchGain,
                        RollGain = s.RollGain,
                        XGain = s.XGain,
                        YGain = s.YGain,
                        ZGain = s.ZGain,
                        StickRangeDeg = s.StickRangeDeg,
                        GyroScale = s.GyroScale,
                        MaxAgeMs = s.MaxAgeMs,
                        MapPosition = s.MapPosition,
                        GlobalSensitivity = s.GlobalSensitivity,
                        GlobalSmoothing = s.GlobalSmoothing,
                    };
                }

                string json = JsonSerializer.Serialize(arr,
                    new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(FilePath, json);
            }
            catch
            {
                // Saving settings is best-effort; never block shutdown over it.
            }
        }

        public static void Load()
        {
            try
            {
                if (!File.Exists(FilePath)) return;

                Dto[] arr = JsonSerializer.Deserialize<Dto[]>(File.ReadAllText(FilePath));
                if (arr == null) return;

                int n = Math.Min(arr.Length, Global.MAX_DS4_CONTROLLER_COUNT);
                for (int i = 0; i < n; i++)
                {
                    Dto d = arr[i];
                    if (d == null) continue;

                    HeadTrackingSettings s = Global.headTracking[i];
                    s.Enabled = d.Enabled;
                    if (!string.IsNullOrEmpty(d.IpAddress)) s.IpAddress = d.IpAddress;
                    s.Port = d.Port;
                    s.Mode = d.Mode;
                    s.InvertYaw = d.InvertYaw;
                    s.InvertPitch = d.InvertPitch;
                    s.InvertRoll = d.InvertRoll;
                    s.InvertX = d.InvertX;
                    s.InvertY = d.InvertY;
                    s.InvertZ = d.InvertZ;
                    s.YawGain = d.YawGain;
                    s.PitchGain = d.PitchGain;
                    s.RollGain = d.RollGain;
                    s.XGain = d.XGain;
                    s.YGain = d.YGain;
                    s.ZGain = d.ZGain;
                    s.StickRangeDeg = d.StickRangeDeg;
                    s.GyroScale = d.GyroScale;
                    s.MaxAgeMs = d.MaxAgeMs;
                    s.MapPosition = d.MapPosition;
                    s.GlobalSensitivity = d.GlobalSensitivity;
                    s.GlobalSmoothing = d.GlobalSmoothing;
                }
            }
            catch
            {
                // Corrupt/old file -> keep defaults.
            }
        }
    }
}
