using System;

namespace DS4Windows
{
    /// <summary>
    /// Owns the per-slot UDP head-tracking listeners and applies their data so the
    /// headset reads as the controller's OWN motion.
    ///
    /// Gyro substitution happens at the device source (DS4Device, right after the
    /// physical gyro is parsed in handleSixaxis), writing into the device's live
    /// cState.Motion. Because every consumer - input mapping, the DSU motion UDP
    /// server, the live readings graph, calibration - derives from that same cState,
    /// they all see the headset as native controller gyro. It is not a late override.
    ///
    /// Socket lifecycle (Reconcile/StopAll) is driven from ControlService. The
    /// device read loop only reads, never starts/stops sockets.
    /// </summary>
    public static class HeadTrackingManager
    {
        private static readonly HeadTrackingUdpListener[] listeners =
            new HeadTrackingUdpListener[Global.MAX_DS4_CONTROLLER_COUNT];

        // Remembers the endpoint we last logged a bind failure for, so a port
        // conflict is reported once (in the Log tab) instead of every frame.
        private static readonly string[] startFailedFor =
            new string[Global.MAX_DS4_CONTROLLER_COUNT];

        // Per-slot smoothing state (exponential moving average of the gyro output).
        private static readonly double[] smYaw = new double[Global.MAX_DS4_CONTROLLER_COUNT];
        private static readonly double[] smPitch = new double[Global.MAX_DS4_CONTROLLER_COUNT];
        private static readonly double[] smRoll = new double[Global.MAX_DS4_CONTROLLER_COUNT];

        public static HeadTrackingUdpListener GetListener(int slot)
            => (slot >= 0 && slot < listeners.Length) ? listeners[slot] : null;

        /// <summary>
        /// Bring the slot's socket in line with its settings: start when enabled,
        /// stop when disabled, rebind on port change. Cheap; safe to call per frame.
        /// </summary>
        public static void Reconcile(int slot)
        {
            if (slot < 0 || slot >= listeners.Length) return;

            HeadTrackingSettings s = Global.headTracking[slot];
            HeadTrackingUdpListener lis = listeners[slot];

            if (s.Enabled)
            {
                if (lis == null) lis = listeners[slot] = new HeadTrackingUdpListener();

                if (!lis.IsRunning)
                {
                    TryStart(slot, lis, s);
                }
                else if (lis.Port != s.Port || lis.BoundAddress != s.IpAddress)
                {
                    lis.Stop();
                    TryStart(slot, lis, s);
                }
            }
            else if (lis != null && lis.IsRunning)
            {
                lis.Stop();
                startFailedFor[slot] = null;
            }
        }

        private static void TryStart(int slot, HeadTrackingUdpListener lis, HeadTrackingSettings s)
        {
            string ep = s.IpAddress + ":" + s.Port;
            try
            {
                lis.Start(s.IpAddress, s.Port);
                startFailedFor[slot] = null;
            }
            catch (Exception ex)
            {
                // Log once per failing endpoint so a port conflict is visible.
                if (startFailedFor[slot] != ep)
                {
                    startFailedFor[slot] = ep;
                    AppLogger.LogToGui($"Head tracking (controller {slot + 1}): could not open UDP {ep} - {ex.Message}. Is the port already in use by another app?", false);
                }
            }
        }

        /// <summary>
        /// Device-source gyro substitution. Called from the controller read loop
        /// right after the physical gyro is parsed. In HijackGyro mode the
        /// controller's gyro IS the UDP angular velocity (zeroed when the data is
        /// stale, so the real gyro never leaks). Read-only with respect to the
        /// socket - lifecycle is handled by Reconcile().
        /// </summary>
        public static void ApplyGyroToMotion(int slot, SixAxis motion)
        {
            if (slot < 0 || slot >= listeners.Length || motion == null) return;

            HeadTrackingSettings s = Global.headTracking[slot];
            if (!s.Enabled || s.Mode != HeadTrackingMode.HijackGyro) return;

            HeadPose p = default;
            bool fresh = false;
            HeadTrackingUdpListener lis = listeners[slot];
            if (lis != null && lis.IsRunning &&
                lis.TryGetPose(out p, s.MaxAgeMs) && !p.Stale)
            {
                fresh = true;
            }

            double vy = 0.0, vp = 0.0, vr = 0.0;
            if (fresh) s.GetGyroOverride(p, out vy, out vp, out vr);

            // Global smoothing: exponential moving average so head jitter reads as
            // smooth analog-like motion. 0 = off (raw); higher = smoother/laggier.
            // When data is stale the target is 0, so aim eases back to center.
            double sm = s.GlobalSmoothing;
            sm = sm < 0.0 ? 0.0 : (sm > 0.95 ? 0.95 : sm);
            double blend = 1.0 - sm;
            smYaw[slot]   += (vy - smYaw[slot])   * blend;
            smPitch[slot] += (vp - smPitch[slot]) * blend;
            smRoll[slot]  += (vr - smRoll[slot])  * blend;
            vy = smYaw[slot];
            vp = smPitch[slot];
            vr = smRoll[slot];

            // Replace every gyro representation the rest of the app reads.
            motion.angVelYaw = vy;
            motion.angVelPitch = vp;
            motion.angVelRoll = vr;

            motion.gyroYawFull = (int)(vy * SixAxis.F_GYRO_RES_IN_DEG_SEC);
            motion.gyroPitchFull = (int)(vp * SixAxis.F_GYRO_RES_IN_DEG_SEC);
            motion.gyroRollFull = (int)(vr * SixAxis.F_GYRO_RES_IN_DEG_SEC);

            motion.gyroYaw = motion.gyroYawFull / 256;
            motion.gyroPitch = motion.gyroPitchFull / 256;
            motion.gyroRoll = motion.gyroRollFull / 256;

            // Position (X/Y/Z) -> accelerometer, only when the toggle is on.
            // Makes the X/Y/Z sliders active just like the rotation ones.
            if (s.MapPosition)
            {
                double ax = 0.0, ay = 0.0, az = 0.0;
                if (fresh) s.GetAccelOverride(p, out ax, out ay, out az);

                motion.accelXG = ax;
                motion.accelYG = ay;
                motion.accelZG = az;

                motion.accelXFull = (int)(ax * SixAxis.F_ACC_RES_PER_G);
                motion.accelYFull = (int)(ay * SixAxis.F_ACC_RES_PER_G);
                motion.accelZFull = (int)(az * SixAxis.F_ACC_RES_PER_G);

                motion.accelX = (int)Math.Clamp(ax * 128.0, -128.0, 128.0);
                motion.accelY = (int)Math.Clamp(ay * 128.0, -128.0, 128.0);
                motion.accelZ = (int)Math.Clamp(az * 128.0, -128.0, 128.0);
            }
        }

        public static void StopAll()
        {
            for (int i = 0; i < listeners.Length; i++)
                listeners[i]?.Stop();
        }
    }
}
