using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace DS4Windows
{
    public enum HeadTrackingMode
    {
        Off = 0,
        HijackGyro = 1,       // replace this controller's gyro with UDP angular velocity
        MapToRightStick = 2,  // orientation -> right stick
        MapToLeftStick = 3,   // orientation -> left stick
    }

    /// <summary>
    /// Per-controller head-tracking options. Implements INotifyPropertyChanged so a
    /// XAML panel can bind directly to it (this IS the view-model). One instance per
    /// profile/controller slot. Persist it alongside the rest of the profile.
    ///
    /// NOTE ON COMPOUNDING: the 6DOFtoUDP.py sender also has invert/gain. Pick ONE
    /// place to invert. These GUI inverts all DEFAULT OFF so they don't fight the
    /// script you already have (which inverts pitch/roll/Y). Leave the script as-is
    /// and flip a GUI invert only if a specific axis still goes the wrong way; or
    /// set the script neutral (all INVERT_*=False, *_GAIN=1) and drive it all here.
    /// </summary>
    public class HeadTrackingSettings : INotifyPropertyChanged
    {
        private bool _enabled;
        private string _ipAddress = "127.0.0.1";
        private int _port = 4242;
        private HeadTrackingMode _mode = HeadTrackingMode.Off;

        private bool _invertYaw, _invertPitch, _invertRoll;
        private bool _invertX, _invertY, _invertZ;

        private double _yawGain = 0.05, _pitchGain = 0.05, _rollGain = 0.05;
        private double _xGain = 0.05, _yGain = 0.05, _zGain = 0.05;

        // MapTo* modes: degrees of head rotation that equal full stick deflection.
        private double _stickRangeDeg = 40.0;
        // When on, head position (X/Y/Z) drives the controller's accelerometer,
        // so the position sliders become active like the rotation ones.
        private bool _mapPosition;
        // HijackGyro mode: multiplier on derived angular velocity (calibration vs real gyro).
        private double _gyroScale = 1.0;
        // Ignore samples older than this (ms); prevents a stalled VR app from freezing aim.
        private double _maxAgeMs = 200.0;

        // Master multiplier applied to every axis on top of the per-axis gains
        // (1.0 = unchanged). Lets you scale overall feel without touching each slider.
        private double _globalSensitivity = 1.0;
        // Low-pass smoothing of the head motion, 0..0.95. 0 = off (rawest/most
        // responsive); higher = smoother but slightly laggier. Applied in the manager
        // as an exponential moving average across frames.
        private double _globalSmoothing = 0.0;

        public bool Enabled { get => _enabled; set => Set(ref _enabled, value); }
        public string IpAddress { get => _ipAddress; set => Set(ref _ipAddress, value); }
        public int Port { get => _port; set => Set(ref _port, value); }
        public HeadTrackingMode Mode { get => _mode; set => Set(ref _mode, value); }

        public bool InvertYaw { get => _invertYaw; set => Set(ref _invertYaw, value); }
        public bool InvertPitch { get => _invertPitch; set => Set(ref _invertPitch, value); }
        public bool InvertRoll { get => _invertRoll; set => Set(ref _invertRoll, value); }
        public bool InvertX { get => _invertX; set => Set(ref _invertX, value); }
        public bool InvertY { get => _invertY; set => Set(ref _invertY, value); }
        public bool InvertZ { get => _invertZ; set => Set(ref _invertZ, value); }

        public double YawGain { get => _yawGain; set => Set(ref _yawGain, value); }
        public double PitchGain { get => _pitchGain; set => Set(ref _pitchGain, value); }
        public double RollGain { get => _rollGain; set => Set(ref _rollGain, value); }
        public double XGain { get => _xGain; set => Set(ref _xGain, value); }
        public double YGain { get => _yGain; set => Set(ref _yGain, value); }
        public double ZGain { get => _zGain; set => Set(ref _zGain, value); }

        public double StickRangeDeg { get => _stickRangeDeg; set => Set(ref _stickRangeDeg, value); }
        public bool MapPosition { get => _mapPosition; set => Set(ref _mapPosition, value); }
        public double GyroScale { get => _gyroScale; set => Set(ref _gyroScale, value); }
        public double MaxAgeMs { get => _maxAgeMs; set => Set(ref _maxAgeMs, value); }
        public double GlobalSensitivity { get => _globalSensitivity; set => Set(ref _globalSensitivity, value); }
        public double GlobalSmoothing { get => _globalSmoothing; set => Set(ref _globalSmoothing, value); }

        // Signed multipliers (invert * gain) so the hot path is one multiply per axis.
        public double YawMul   => (InvertYaw   ? -1.0 : 1.0) * YawGain;
        public double PitchMul => (InvertPitch ? -1.0 : 1.0) * PitchGain;
        public double RollMul  => (InvertRoll  ? -1.0 : 1.0) * RollGain;
        public double XMul     => (InvertX     ? -1.0 : 1.0) * XGain;
        public double YMul     => (InvertY     ? -1.0 : 1.0) * YGain;
        public double ZMul     => (InvertZ     ? -1.0 : 1.0) * ZGain;

        /// <summary>HijackGyro mode: angular velocity (deg/s) scaled into gyro units.</summary>
        public void GetGyroOverride(in HeadPose p, out double yaw, out double pitch, out double roll)
        {
            double g = GyroScale * GlobalSensitivity;
            yaw   = p.AngVelYaw   * YawMul   * g;
            pitch = p.AngVelPitch * PitchMul * g;
            roll  = p.AngVelRoll  * RollMul  * g;
        }

        /// <summary>MapTo* modes: orientation -> normalized stick axes in [-1, 1].</summary>
        public void GetStickOutput(in HeadPose p, out double stickX, out double stickY)
        {
            double range = StickRangeDeg <= 0 ? 1.0 : StickRangeDeg;
            stickX = Clamp((p.Yaw   * YawMul)   / range, -1.0, 1.0);
            stickY = Clamp((p.Pitch * PitchMul) / range, -1.0, 1.0);
        }

        /// <summary>
        /// When MapPosition is on: head position (cm) -> accelerometer (g), per axis,
        /// scaled by the X/Y/Z gain sliders. ~1 m of lean == 1 g before gain.
        /// </summary>
        public void GetAccelOverride(in HeadPose p, out double ax, out double ay, out double az)
        {
            const double CM_TO_G = 0.01;
            double g = CM_TO_G * GlobalSensitivity;
            ax = p.X * XMul * g;
            ay = p.Y * YMul * g;
            az = p.Z * ZMul * g;
        }

        private static double Clamp(double v, double lo, double hi)
            => v < lo ? lo : (v > hi ? hi : v);

        public event PropertyChangedEventHandler PropertyChanged;
        private void Set<T>(ref T field, T value, [CallerMemberName] string name = null)
        {
            if (Equals(field, value)) return;
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
