using System.Windows.Controls;

namespace DS4WinWPF.DS4Forms
{
    public partial class HeadTrackingControl : UserControl
    {
        public HeadTrackingControl()
        {
            InitializeComponent();
        }
    }
}
